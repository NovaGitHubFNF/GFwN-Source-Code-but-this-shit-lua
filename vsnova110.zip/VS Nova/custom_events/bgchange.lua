function onEvent(name, value1, value2)
   
    makeLuaSprite(value2, value1);
    addLuaSprite(value2, false);
    
    
    
    end
