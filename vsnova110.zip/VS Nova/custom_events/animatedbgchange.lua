function onEvent(name, value1, value2)
   
    makeAnimatedLuaSprite( value2, value1, 0, 0);
    addLuaSprite(value2, false);
    
    
    
    end
