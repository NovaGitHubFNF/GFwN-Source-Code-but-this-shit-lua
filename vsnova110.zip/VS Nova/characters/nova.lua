function opponentNoteHit()
	if getProperty('health') > 0.4 then
	setProperty('health',getProperty('health')-0.015)
 end
end