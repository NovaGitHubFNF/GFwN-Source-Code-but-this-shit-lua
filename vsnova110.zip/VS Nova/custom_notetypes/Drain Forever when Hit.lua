function onCreate()
	for i = 0, getProperty('unspawnNotes.length')-1 do
	if getPropertyFromGroup('unspawnNotes', i, 'noteType') == 'Drain Forever when Hit' then
		setPropertyFromGroup('unspawnNotes', i, 'texture', 'Pnotes');
		setPropertyFromGroup('unspawnNotes', i, 'ignoreNote', true);
		end
	end
end
--function goodNoteHit(id, noteData, noteType, isSustainNote)
--	if noteType == 'Drain Forever when Hit' then
--	runTimer('dmg', 0.001, 0);		
--    setProperty('songMisses', getProperty('songMisses')+1);
--	end
--end

--function onTimerCompleted(tag, loops, loopsLeft)
--	if tag == 'dmg' then
--	setProperty('health', getProperty('health')-0.001, 9000000);
--	end
--end

function min(a,b) if a > b then return b else return a end end
local notes = {
    ["ebola"] = {
        misses = 0,
        max = 10,
        func = function(self)
            gonnaDie = true
            gonnaDieAmm = (min(self.misses,self.max) * 0.001);
        end,
    },
}
function goodNoteHit(id, noteData, noteType, isSustainNote)
    if (notes[noteType]) then
        notes[noteType].misses = notes[noteType].misses + 1
        if notes[noteType].func then
            notes[noteType].func(notes[noteType])
        end
    end
end
gonnaDie = false;
gonnaDieAmm = 0;

function onUpdate(elapsed)
    if (gonnaDie) then
        setProperty('health', getProperty('health') - gonnaDieAmm);
    end
end