Put your pixel noteskins here!
make sure to give them a unique name.
if you came to fix crashes, give them the same name as your normal noteskin
for example, mine is called "Simply_Perfect"
so here, pixel assets would be named like this

"Simply_Perfect.png"
"Simply_PerfectENDS.png"