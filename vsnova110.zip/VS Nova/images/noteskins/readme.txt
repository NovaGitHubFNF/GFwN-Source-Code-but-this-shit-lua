Put your noteskins and noteskin jsons here!
make sure to give them a unique name.