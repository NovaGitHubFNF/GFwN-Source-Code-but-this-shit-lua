Put your judgement skins here!
make sure to create a folder, give the folder a unique name, and then place your judgements there.

if a specific judgement is missing (like sick for example), it will use the classic ones.