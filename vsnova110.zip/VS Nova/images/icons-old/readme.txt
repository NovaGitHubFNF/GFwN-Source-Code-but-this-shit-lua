Put your custom character icons here!
this one is for icons that have only two states
Icons must start with "icon-" or it won't be read!
use the template if you are confused on the exact resolution for them