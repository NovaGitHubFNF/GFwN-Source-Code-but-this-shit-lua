You can either edit files or add entirely new ones here.

to make your mod or modpack have a name and description, edit the example pack.json file
to make your mod or modpack have an image, edit the example image file

you can also put your files inside an individual folder for better organization

ABOUT EDITTING:
It doesn't matter if you want to edit something in assets/shared/images/ or assets/preload/images/,
you will have to put the editted files in mods/images/, it will be handled automatically by the engine.
