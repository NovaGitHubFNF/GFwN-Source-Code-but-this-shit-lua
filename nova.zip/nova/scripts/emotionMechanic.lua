--Note from Stahl: This is a really big script lol, hopefully comments helps
--Note 2: This went through overhaul and uses table rather than if-else now; more organized and versatile. Not sure about performance though.

--VARIABLES
local charEmo = {'neutral', 'neutral'} --dad then boyfriend, rememeber lua array starts at 1 but haxe start at 0
local emoObj = {'dadstate', 'bfstate'} --for actual sprite display, lua object

--list of emotions, emotion = {element, tier}
local emoTable = {
	neutral = {"neutral", 1},
	happy = {"happy", 1},
	ecstatic = {"happy", 2},
	manic = {"happy", 3},
	sad = {"sad", 1},
	depressed = {"sad", 2},
	miserable = {"sad", 3},
	angry = {"angry", 1},
	enraged = {"angry", 2},
	furious = {"angry", 3},
	afraid = {"afraid", 1},
	stressed = {"afraid", 2}
}

-- Emotion table; happy > angry > sad > happy; afraid is weak to all.
local advTable = {
	happy = {"angry"},
	angry = {"sad"},
	sad = {"happy"}
}

--STUFF FOR REAL
function onCreate()
	--y position for down or upscroll
	stateY = 635;
	if downscroll then
		stateY = 65
	end
	
	makeAnimatedLuaSprite(emoObj[1], 'misc/UI/statelist', 130, stateY)
	makeAnimatedLuaSprite(emoObj[2], 'misc/UI/statelist', 1000, stateY)
	
	for i = 1,#emoObj do
		--does the same thing for 2 sprites
		for k, v in pairs(emoTable) do
			addAnimationByPrefix(emoObj[i], k, k, 24, true)
		end

		objectPlayAnimation(emoObj[i], 'neutral', true)
		setScrollFactor(emoObj[i], 0, 0)
		setObjectCamera(emoObj[i], 'hud')
		addLuaSprite(emoObj[i], true)
	end
end

function onCreatePost()
	--at start set emotion to starting sprite
	emoToSpr()

	--HARD CODED STAGES THAT EMOTION DOESN'T APPEAR
	if songName == 'Headspace' then
		setProperty(emoObj[1]..'.visible', false)
		setProperty(emoObj[2]..'.visible', false)
	elseif songName == 'Guilty' then
		for i = 1,#emoObj do
			local originalY = getProperty(emoObj[i]..'.y')
			setProperty(emoObj[i]..'.y', originalY + 40)
			setProperty(emoObj[i]..'.alpha', 0)
			doTweenY('emoY'..i, emoObj[i], originalY, 2, 'cubeOut')
			doTweenAlpha('emoAlpha'..i, emoObj[i], 1, 2, 'cubeOut')
		end
	end
end

--RETURN FUNCTIONS

--Tells emotion element for advantage calculation
function element(emo)
	for k, v in pairs(emoTable) do
		if emo == k then
			return v[1]
		end
	end
end

--Tells tier, used see how big of a multiplier of advantage.
--Technically in Omori STRESSED is actually tier 3 AFRAID, with unused PANIC being the tier 2. For here STRESSED is considered tier 2.
function tier(emo)
	for k, v in pairs(emoTable) do
		if emo == k then
			return v[2]
		end
	end
end

--Returns boolean, advantage of first variable.
function emoAdvantage(emoA, emoB)
	for k, v in pairs(advTable) do
		if element(emoA) == k and element(emoB) == v[1] then
			return true
		else
			return false
		end
	end
end

--Takes emotion string and compares it. Returns integer, find difference, taking advantage into account
function emoDiff(emoA, emoB)
	--firstly check if A or B is neutral, if is then don't do Advantage Triangle 
	if emoA == 'neutral' or emoB == 'neutral' then
		--afraid always has some value regardless of opponent
		if element(emoA) == 'afraid' then
			return tier(emoA) * -1
		elseif element(emoB) == 'afraid' then
			return tier(emoB) * 1
		else
			return 0
		end
	else
		if emoAdvantage(emoA, emoB) then
			--if advantageous, A > B, then Difference is A + B
			--Example: Manic is 3, vs Enraged is 2; Difference is 5 (positive)
			return (tier(emoA) + tier(emoB)) * 1
		else
			--if disadvantageous, A < B, then Difference is -(A + B)
			--Example: Manic is 3, vs Depressed is 2; Difference is -5 (negative)
			return (tier(emoA) + tier(emoB)) * -1
		end
	end
end

--GENERAL FUNCTIONS

--sets emotion, sprite is only updated when changed in the same function to avoid playing anim every frame on update instead
function emoSet(aff, setEmo)
	charEmo[aff] = setEmo
	objectPlayAnimation(emoObj[aff], setEmo, true)
end

--Add emotions. Character then Emotion added
function emoAdd(aff, eff)
	emo = charEmo[aff]
	
	--if element trying to be added is the same, add a tier; if not, set to that
	if element(emo) == element(eff) then
		for k, v in pairs(emoTable) do
			--checks the table for ones with same element and same (tier + added emo)
			if v[1] == element(emo) and v[2] == tier(emo) + tier(eff) then
				emo = k
			end
		end
	else
		emo = eff
	end
	
	emoSet(aff, emo)
end

--sets emotion to current sprite, finds "-emotion" at the end of curCharacter name
function emoToSpr()
	for k, v in pairs(emoTable) do	
		if string.match(getProperty('dad.curCharacter'), "-"..k) then
			emoSet(1, k)
		end

		if string.match(getProperty('boyfriend.curCharacter'), "-"..k) then
			emoSet(2, k)
		end
	end
end

-- NOTE ADVANTAGE
--Rememver this is added on top of already normal health gain
function goodNoteHit(id, direction, noteType, isSustainNote)
	curHealth = getProperty('health');
	--0.004 health increment per tier. Max is 0.004 * 6 = 0.024
	amount = emoDiff(charEmo[2], charEmo[1])/250
	
	--bf is the one gaining health, so advantage realtive to bf
	if isSustainNote then
		setProperty('health', curHealth + (amount/6))
	else
		setProperty('health', curHealth + amount)
	end
end


function noteMiss(id, direction, noteType, isSustainNote)
	curHealth = getProperty('health');
	--0.004 health increment per tier. Max is 0.004 * 6 = 0.024
	amount = emoDiff(charEmo[2], charEmo[1])/250
	
	--bf is the one gaining health, so advantage realtive to bf
	if isSustainNote then
		setProperty('health', curHealth + (amount/6))
	else
		setProperty('health', curHealth + amount)
	end
end

function opponentNoteHit(id, direction, noteType, isSustainNote)
	curHealth = getProperty('health');
	if charEmo[1] == 'angry' then
		if getProperty('health') >= 0.1 then
			setProperty('health', curHealth-0.005)
		end
	end
	if charEmo[1] == 'enraged' then
		if getProperty('health') >= 0.1 then
			setProperty('health', curHealth-0.01)
		end
	end
	if charEmo[1] == 'furious' then
		if getProperty('health') >= 0.1 then
			setProperty('health', curHealth-0.015)
		end
	end
end


--EVENT STUFF
function onEvent(name, value1, value2)
	--added one for character affected since lua arrays starts starts at 1
	--Sets an emotion. Value 1: 0 = dad, 1 = boyfriend. Value 2 is emotion like 'ecstatic'
	if name == 'emoSet' then 
		emoSet(value1 + 1, tostring(value2))
	end
	
	--Adds an emotion. Value 1: 0 = dad, 1 = boyfriend. Value 2 is emotion element like 'happy'
	if name == 'emoAdd' then
		emoAdd(value1 + 1, tostring(value2))
	end

	--Change Character to current emotion. Value 1: Dad, Value 2: bf
	if name == 'omoSprEmo' then
		target = tonumber(value1) --0 dad, 1 bf
		charName = tostring(value2)
		--Change Character event description was a lie, its bf = 0, dad = 1, gf = 2
		if target == 0 then --Dad
			triggerEvent('Change Character', 1, charName.."-"..charEmo[1])
			--debugPrint('change character dad: ', charName.."-"..charEmo[1])
		else --Dad
			triggerEvent('Change Character', 0, charName.."-"..charEmo[2])
		end
	end
end



--// DEBUGGING //--
function debugEmo()
	debugPrint('dadstate: ', charEmo[1])
	debugPrint('dadstate tier: ', tier(charEmo[1]))
	debugPrint('dadstate element: ', element(charEmo[1]))
	debugPrint('bfstate: ', charEmo[2])
	debugPrint('bfstate tier: ', tier(charEmo[2]))
	debugPrint('bfstate element: ', element(charEmo[2]))
end

function debugEmo2()
	debugPrint('bf emoDiff: ', emoDiff(charEmo[2], charEmo[1]))
	debugPrint('dad emoDiff: ', emoDiff(charEmo[1], charEmo[2]))
end

function debugEmo3()
	debugPrint('elementFE: ', element('furious'))
	debugPrint('elementFT: ', tier('furious'))
	debugPrint('Adv: ', emoAdvantage('furious', 'happy'))
end