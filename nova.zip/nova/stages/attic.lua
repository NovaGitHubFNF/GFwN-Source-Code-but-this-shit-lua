function onCreate()
	-- background shit
	makeLuaSprite('bg1', 'NOVA_ATTIC', 640, 470);
	setLuaSpriteScrollFactor('bg1', 1, 1);
	scaleObject('bg1', 1.1, 1.1);

	makeLuaSprite('overlay', 'atticoverlay', 640, 470);
	setLuaSpriteScrollFactor('overlay', 1, 1);
	scaleObject('overlay', 1.1, 1.1);

	addLuaSprite('bg1', false);
	addLuaSprite('overlay', true);
	
end